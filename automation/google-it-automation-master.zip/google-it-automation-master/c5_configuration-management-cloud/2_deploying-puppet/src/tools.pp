package { 'htop':
    ensure => present,
}